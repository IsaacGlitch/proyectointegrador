document.addEventListener('DOMContentLoaded', () => {
  const toggleBtn = document.getElementById('chatbot-toggle');
  const chatWindow = document.getElementById('chatbot-window');
  const closeBtn = document.getElementById('chatbot-close');
  const input = document.getElementById('userInput');
  const messages = document.getElementById('chatbot-messages');
  const chatbotContainer = document.getElementById('chatbot');

  function checkFooterVisibility() {
    const footer = document.querySelector('footer');
    if (!footer) return;

    const footerRect = footer.getBoundingClientRect();
    const windowHeight = window.innerHeight || document.documentElement.clientHeight;

    if (footerRect.top < windowHeight && footerRect.bottom >= 0) {
      chatbotContainer.style.display = 'block';
    } else {
      chatbotContainer.style.display = 'none';
      chatWindow.style.display = 'none';
      toggleBtn.style.display = 'inline-block';
    }
  }

  window.addEventListener('scroll', checkFooterVisibility);
  window.addEventListener('resize', checkFooterVisibility);
  window.addEventListener('load', checkFooterVisibility);

  toggleBtn.addEventListener('click', () => {
    chatWindow.style.display = 'flex';
    toggleBtn.style.display = 'none';
    input.focus();
  });

  closeBtn.addEventListener('click', () => {
    chatWindow.style.display = 'none';
    toggleBtn.style.display = 'inline-block';
  });

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && input.value.trim() !== '') {
      addMessage('Tú', input.value.trim());
      const respuesta = getBotResponse(input.value.trim().toLowerCase());
      addMessage('Bot', respuesta);
      input.value = '';
    }
  });

  function addMessage(sender, text) {
    const p = document.createElement('p');
    p.style.margin = '5px 0';
    p.innerHTML = `<strong>${sender}:</strong> ${text.replace(/\n/g, '<br>')}`;
    messages.appendChild(p);
    messages.scrollTop = messages.scrollHeight;
  }

  function mostrarMenu() {
    return `Hola, soy el bot de Cinepoint 🎬. ¿En qué puedo ayudarte? Escribe el número de la opción:
1. Próximos estrenos
2. Información de películas
3. Horarios de cine
4. Promociones actuales
5. Contacto o ayuda
6. Salir`;
  }

  function getBotResponse(input) {
    switch (input) {
      case '1':
        return `Estos son los próximos estrenos:

- Interstellar (24 ABR 2025)
- El Padrino (24 ABR 2025)
- La La Land (24 ABR 2025)
- Titanic (24 ABR 2025)

¿Quieres información de alguna película? Escribe su nombre.`;
      case '2':
        return `Películas populares:
- Interstellar
- Titanic
- Joker
- Avengers
Escribe el nombre para saber más.`;
      case 'interstellar':
        return `Interstellar (2014) es una película de ciencia ficción dirigida por Christopher Nolan. Trata sobre un grupo de exploradores que viajan a través de un agujero de gusano buscando un nuevo hogar para la humanidad.`;
      case 'titanic':
        return `Titanic (1997) es un drama romántico dirigido por James Cameron, basado en el hundimiento del famoso barco RMS Titanic en 1912.`;
      case 'joker':
        return `Joker (2019) es un drama psicológico protagonizado por Joaquin Phoenix que explora el origen del villano de Batman.`;
      case 'avengers':
        return `Avengers es una serie de películas de superhéroes del universo Marvel que reúnen a varios personajes icónicos.`;
      case '3':
        return `Los horarios de cine son:

- Lunes a viernes: 2pm, 5pm, 8pm
- Sábados y domingos: 1pm, 4pm, 7pm, 10pm

Para más detalles, visita nuestra sección de horarios en la página.`;
      case '4':
        return `Promociones actuales:

- 2x1 en entradas los miércoles.
- Descuento del 20% para estudiantes.
- Combo popcorn + bebida por $5.

Consulta términos y condiciones.`;
      case '5':
        return `Puedes contactarnos en:
        
- Email: soporte@cinepoint.com
- Teléfono: +1 234 567 890
- Redes sociales: Facebook, Instagram, Twitter @cinepoint`;
      case '6':
      case 'salir':
        return `¡Gracias por usar el bot de Cinepoint! Escribe "menu" para volver a empezar.`;
      case 'menu':
        return mostrarMenu();
      default:
        return `No entendí tu mensaje. Escribe "menu" para ver las opciones o un número del 1 al 6.`;
    }
  }

  // Mostrar saludo y menú al iniciar
  addMessage('Bot', mostrarMenu());
});
