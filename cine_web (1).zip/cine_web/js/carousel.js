  document.addEventListener('DOMContentLoaded', () => {
    const slides = document.querySelectorAll('#slides img');
    let index = 0;

    function showSlide(i) {
      slides.forEach(img => img.classList.remove('active'));
      if (i < 0) index = slides.length - 1;
      else if (i >= slides.length) index = 0;
      else index = i;
      slides[index].classList.add('active');
    }

    function nextSlide() {
      showSlide(index + 1);
    }

    function prevSlide() {
      showSlide(index - 1);
    }

    document.querySelector('.next').addEventListener('click', nextSlide);
    document.querySelector('.prev').addEventListener('click', prevSlide);

    setInterval(() => {
      nextSlide();
    }, 5000);

    showSlide(index);
  });