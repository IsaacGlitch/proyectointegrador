<?php
$host = 'localhost';     // Dirección del servidor (usualmente localhost)
$db = 'cine_web';      // Nombre de la base de datos
$user = 'root';         // Usuario de la base de datos
$pass = '';             // Contraseña de la base de datos

try {
    // Conectar a la base de datos usando PDO
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Manejo de errores
} catch (PDOException $e) {
    echo "Error de conexión: " . $e->getMessage(); // Mostrar error si la conexión falla
}
?>