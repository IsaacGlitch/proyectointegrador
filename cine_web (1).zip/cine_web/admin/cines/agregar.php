<?php
// Verificar autenticación de administrador
require_once 'admin_check.php';

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Recoger los datos del formulario
        $nombre = $_POST['nombre'];
        $direccion = $_POST['direccion'];
        $imagen = $_POST['imagen'];
        $ciudad = $_POST['ciudad'];
        $telefono = $_POST['telefono'];
        $horario_atencion = $_POST['horario_atencion'];

        // Insertar los datos en la base de datos
        $sql = "INSERT INTO cines (nombre, direccion, imagen, ciudad, telefono, horario_atencion)
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$nombre, $direccion, $imagen, $ciudad, $telefono, $horario_atencion]);

        $success_message = "¡Cine agregado exitosamente!";
    } catch (Exception $e) {
        $error_message = "Error al agregar el cine: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Cine - Administración</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/agregar.css"> <!-- Se separa el CSS -->
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-plus-circle"></i> Agregar Cine</h1>
            <p class="subtitle">Añade un nuevo cine al directorio</p>
        </div>

        <div class="content">
            <a href="manage.php" class="back-button">
                <i class="fas fa-arrow-left"></i>
                Volver a la lista
            </a>

            <?php if ($success_message): ?>
                <div class="alert success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>

            <?php if ($error_message): ?>
                <div class="alert error">
                    <i class="fas fa-exclamation-triangle"></i>
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <div class="form-tips">
                <h3><i class="fas fa-lightbulb"></i> Consejos para agregar cines:</h3>
                <ul>
                    <li>Usa URLs de imágenes de alta calidad del exterior del cine</li>
                    <li>El horario debe incluir AM/PM (ej: "10:00 AM - 10:00 PM")</li>
                    <li>El teléfono debe ser un número peruano válido (9 dígitos)</li>
                    <li>Incluye la dirección completa con referencias si es necesario</li>
                </ul>
            </div>

            <div class="form-container">
                <form action="agregar.php" method="POST" id="cineForm">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="nombre">
                                <i class="fas fa-building"></i>
                                Nombre del Cine <span class="required">*</span>
                            </label>
                            <input type="text" name="nombre" id="nombre" required maxlength="100" placeholder="Ej: Cinepoint San Miguel">
                            <div class="char-counter" id="nombre-counter">0/100</div>
                        </div>

                        <div class="form-group">
                            <label for="ciudad">
                                <i class="fas fa-map-marker-alt"></i>
                                Ciudad <span class="required">*</span>
                            </label>
                            <input type="text" name="ciudad" id="ciudad" required maxlength="100" placeholder="Ej: Lima, Arequipa, Cusco">
                            <div class="char-counter" id="ciudad-counter">0/100</div>
                        </div>

                        <div class="form-group">
                            <label for="telefono">
                                <i class="fas fa-phone"></i>
                                Teléfono <span class="required">*</span>
                            </label>
                            <input type="tel" name="telefono" id="telefono" required placeholder="987654321" maxlength="9" pattern="[0-9]{9}">
                            <div class="char-counter" id="telefono-counter">0/9</div>
                        </div>

                        <div class="form-group">
                            <label for="horario_atencion">
                                <i class="fas fa-clock"></i>
                                Horario de Atención <span class="required">*</span>
                            </label>
                            <input type="text" name="horario_atencion" id="horario_atencion" required maxlength="100" placeholder="10:00 AM - 10:00 PM">
                            <div class="char-counter" id="horario-counter">0/100</div>
                        </div>

                        <div class="form-group full-width">
                            <label for="direccion">
                                <i class="fas fa-map-pin"></i>
                                Dirección <span class="required">*</span>
                            </label>
                            <input type="text" name="direccion" id="direccion" required maxlength="255" placeholder="Av. La Marina 2355, San Miguel">
                            <div class="char-counter" id="direccion-counter">0/255</div>
                        </div>

                        <div class="form-group full-width">
                            <label for="imagen">
                                <i class="fas fa-image"></i>
                                URL de la Imagen <span class="required">*</span>
                            </label>
                            <input type="url" name="imagen" id="imagen" required placeholder="https://ejemplo.com/imagen-cine.jpg">
                            <div class="image-preview" id="imagePreview"></div>
                        </div>
                    </div>

                    <button type="submit" class="submit-button">
                        <i class="fas fa-save"></i>
                        Agregar Cine
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script src="js/agregar.js"></script> <!-- Se separa el JavaScript -->
</body>
</html>