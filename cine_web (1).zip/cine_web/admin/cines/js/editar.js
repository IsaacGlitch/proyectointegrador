        // Contador de caracteres
        function setupCharCounter(inputId, counterId, maxLength) {
            const input = document.getElementById(inputId);
            const counter = document.getElementById(counterId);
            
            function updateCounter() {
                const currentLength = input.value.length;
                counter.textContent = `${currentLength}/${maxLength}`;
                
                if (currentLength > maxLength * 0.9) {
                    counter.style.color = '#e74c3c';
                } else if (currentLength > maxLength * 0.7) {
                    counter.style.color = '#f39c12';
                } else {
                    counter.style.color = '#7f8c8d';
                }
            }
            
            updateCounter(); // Inicializar
            input.addEventListener('input', updateCounter);
        }

        // Preview de imagen
        function updateImagePreview() {
            const url = document.getElementById('imagen').value;
            const preview = document.getElementById('imagePreview');
            
            if (url) {
                preview.innerHTML = `<img src="${url}" alt="Preview" onerror="this.parentNode.innerHTML='<p style=color:#e74c3c><i class=fas fa-exclamation-triangle></i> Error al cargar la imagen</p>'">`;
            } else {
                preview.innerHTML = '';
            }
        }

        document.getElementById('imagen').addEventListener('input', updateImagePreview);

        // Inicializar contadores
        setupCharCounter('nombre', 'nombre-counter', 100);
        setupCharCounter('ciudad', 'ciudad-counter', 100);
        setupCharCounter('horario_atencion', 'horario-counter', 100);
        setupCharCounter('direccion', 'direccion-counter', 255);

        // Validación del formulario
        document.getElementById('editForm').addEventListener('submit', function(e) {
            const telefono = document.getElementById('telefono').value;
            
            // Validación básica del teléfono (solo números, espacios, guiones y paréntesis)
            const telefonoRegex = /^[\d\s\-\(\)\+]+$/;
            if (!telefonoRegex.test(telefono)) {
                e.preventDefault();
                alert('El teléfono solo puede contener números, espacios, guiones y paréntesis');
                return;
            }
        });

        // Mostrar preview inicial si hay imagen
        updateImagePreview();