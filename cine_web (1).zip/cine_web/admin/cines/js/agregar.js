        // Contador de caracteres
        function setupCharCounter(inputId, counterId, maxLength) {
            const input = document.getElementById(inputId);
            const counter = document.getElementById(counterId);
            
            input.addEventListener('input', function() {
                const currentLength = this.value.length;
                counter.textContent = `${currentLength}/${maxLength}`;
                
                if (currentLength > maxLength * 0.9) {
                    counter.style.color = '#e74c3c';
                } else if (currentLength > maxLength * 0.7) {
                    counter.style.color = '#f39c12';
                } else {
                    counter.style.color = '#7f8c8d';
                }
            });
        }

        // Preview de imagen
        document.getElementById('imagen').addEventListener('input', function() {
            const url = this.value;
            const preview = document.getElementById('imagePreview');
            
            if (url) {
                preview.innerHTML = `<img src="${url}" alt="Preview" onerror="this.parentNode.innerHTML='<p style=color:#e74c3c><i class=fas fa-exclamation-triangle></i> Error al cargar la imagen</p>'">`;
            } else {
                preview.innerHTML = '';
            }
        });

        // Validación de teléfono peruano
        document.getElementById('telefono').addEventListener('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
            if (this.value.length > 9) {
                this.value = this.value.substring(0, 9);
            }
        });

        // Inicializar contadores
        setupCharCounter('nombre', 'nombre-counter', 100);
        setupCharCounter('ciudad', 'ciudad-counter', 100);
        setupCharCounter('direccion', 'direccion-counter', 255);
        setupCharCounter('telefono', 'telefono-counter', 9);
        setupCharCounter('horario_atencion', 'horario-counter', 100);

        // Validación del formulario
        document.getElementById('cineForm').addEventListener('submit', function(e) {
            const telefono = document.getElementById('telefono').value;
            
            if (telefono.length !== 9) {
                e.preventDefault();
                alert('El teléfono debe tener exactamente 9 dígitos');
                return;
            }
            
            if (!telefono.match(/^[0-9]{9}$/)) {
                e.preventDefault();
                alert('El teléfono debe contener solo números');
                return;
            }
        });