<?php
// Verificar autenticación de administrador
require_once 'admin_check.php';

$success_message = '';
$error_message = '';

// Obtener el ID del cine desde la URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: manage.php');
    exit;
}

$id_cine = $_GET['id'];

// Consultar el cine específico para editar
$sql = "SELECT * FROM cines WHERE id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id_cine]);
$cine = $stmt->fetch();

// Verificar si el cine existe
if (!$cine) {
    $error_message = "Cine no encontrado.";
} else {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        try {
            // Recoger los datos del formulario
            $nombre = $_POST['nombre'];
            $direccion = $_POST['direccion'];
            $imagen = $_POST['imagen'];
            $ciudad = $_POST['ciudad'];
            $telefono = $_POST['telefono'];
            $horario_atencion = $_POST['horario_atencion'];

            // Actualizar los datos del cine en la base de datos
            $sql = "UPDATE cines SET nombre = ?, direccion = ?, imagen = ?, ciudad = ?, telefono = ?, horario_atencion = ? WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$nombre, $direccion, $imagen, $ciudad, $telefono, $horario_atencion, $id_cine]);

            $success_message = "¡Cine actualizado exitosamente!";
            
            // Refrescar los datos del cine
            $sql = "SELECT * FROM cines WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$id_cine]);
            $cine = $stmt->fetch();
        } catch (Exception $e) {
            $error_message = "Error al actualizar el cine: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Cine - Administración</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/editar.css"> <!-- Se separa el CSS -->
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-edit"></i> Editar Cine</h1>
            <p class="subtitle">Modifica los datos del cine</p>
            <?php if ($cine): ?>
                <div class="movie-id">ID: <?php echo htmlspecialchars($cine['id']); ?></div>
            <?php endif; ?>
        </div>

        <div class="content">
            <div class="navigation">
                <a href="manage.php" class="nav-button back-button">
                    <i class="fas fa-arrow-left"></i>
                    Volver a la lista
                </a>
            </div>

            <?php if ($success_message): ?>
                <div class="alert success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>

            <?php if ($error_message): ?>
                <div class="alert error">
                    <i class="fas fa-exclamation-triangle"></i>
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <?php if ($cine): ?>
                <div class="current-info">
                    <h3><i class="fas fa-info-circle"></i> Información actual</h3>
                    <div class="current-preview">
                        <div>
                            <?php if (!empty($cine['imagen'])): ?>
                                <img src="<?php echo htmlspecialchars($cine['imagen']); ?>" 
                                     alt="<?php echo htmlspecialchars($cine['nombre']); ?>" 
                                     class="current-image"
                                     onerror="this.parentNode.innerHTML='<div class=\'no-image-current\'><i class=\'fas fa-building\'></i></div>'">
                            <?php else: ?>
                                <div class="no-image-current"><i class="fas fa-building"></i></div>
                            <?php endif; ?>
                        </div>
                        <div class="current-details">
                            <div class="detail-item">
                                <div class="detail-label">Nombre</div>
                                <div class="detail-value"><?php echo htmlspecialchars($cine['nombre']); ?></div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Ciudad</div>
                                <div class="detail-value"><?php echo htmlspecialchars($cine['ciudad']); ?></div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Teléfono</div>
                                <div class="detail-value"><?php echo htmlspecialchars($cine['telefono']); ?></div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Horario</div>
                                <div class="detail-value"><?php echo htmlspecialchars($cine['horario_atencion']); ?></div>
                            </div>
                            <div class="detail-item" style="grid-column: 1 / -1;">
                                <div class="detail-label">Dirección</div>
                                <div class="detail-value"><?php echo htmlspecialchars(substr($cine['direccion'], 0, 100)) . (strlen($cine['direccion']) > 100 ? '...' : ''); ?></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-container">
                    <div class="form-header">
                        <h2><i class="fas fa-pencil-alt"></i> Modificar datos</h2>
                        <p>Actualiza los campos que desees cambiar</p>
                    </div>

                    <form action="editar.php?id=<?php echo $cine['id']; ?>" method="POST" id="editForm">
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="nombre">
                                    <i class="fas fa-building"></i>
                                    Nombre del Cine <span class="required">*</span>
                                </label>
                                <input type="text" name="nombre" id="nombre" 
                                       value="<?php echo htmlspecialchars($cine['nombre']); ?>" 
                                       required maxlength="100">
                                <div class="char-counter" id="nombre-counter"></div>
                            </div>

                            <div class="form-group">
                                <label for="ciudad">
                                    <i class="fas fa-city"></i>
                                    Ciudad <span class="required">*</span>
                                </label>
                                <input type="text" name="ciudad" id="ciudad" 
                                       value="<?php echo htmlspecialchars($cine['ciudad']); ?>" 
                                       required maxlength="100">
                                <div class="char-counter" id="ciudad-counter"></div>
                            </div>

                            <div class="form-group">
                                <label for="telefono">
                                    <i class="fas fa-phone"></i>
                                    Teléfono <span class="required">*</span>
                                </label>
                                <input type="tel" name="telefono" id="telefono" 
                                       value="<?php echo htmlspecialchars($cine['telefono']); ?>" 
                                       required maxlength="20">
                            </div>

                            <div class="form-group">
                                <label for="horario_atencion">
                                    <i class="fas fa-clock"></i>
                                    Horario de Atención <span class="required">*</span>
                                </label>
                                <input type="text" name="horario_atencion" id="horario_atencion" 
                                       value="<?php echo htmlspecialchars($cine['horario_atencion']); ?>" 
                                       required maxlength="100"
                                       placeholder="Ej: 10:00 AM - 10:00 PM">
                                <div class="char-counter" id="horario-counter"></div>
                            </div>

                            <div class="form-group full-width">
                                <label for="imagen">
                                    <i class="fas fa-image"></i>
                                    URL de la Imagen <span class="required">*</span>
                                </label>
                                <input type="url" name="imagen" id="imagen" 
                                       value="<?php echo htmlspecialchars($cine['imagen']); ?>" required>
                                <div class="image-preview" id="imagePreview"></div>
                            </div>

                            <div class="form-group full-width">
                                <label for="direccion">
                                    <i class="fas fa-map-marker-alt"></i>
                                    Dirección <span class="required">*</span>
                                </label>
                                <textarea name="direccion" id="direccion" required maxlength="255"><?php echo htmlspecialchars($cine['direccion']); ?></textarea>
                                <div class="char-counter" id="direccion-counter"></div>
                            </div>
                        </div>

                        <button type="submit" class="submit-button">
                            <i class="fas fa-save"></i>
                            Actualizar Cine
                        </button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="js/editar.js"></script> <!-- Se separa el JavaScript -->
</body>
</html>