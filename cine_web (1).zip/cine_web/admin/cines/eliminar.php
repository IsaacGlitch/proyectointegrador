<?php
// Verificar autenticación de administrador
require_once 'admin_check.php';

// Obtener el ID de la película desde la URL
$id_cine = $_GET['id'];

// Eliminar la película de la base de datos
$sql = "DELETE FROM cines WHERE id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id_cine]);

// Redirigir de vuelta a la página de administración
header("Location: manage.php");
exit;
?>