<?php
session_start();

// Verificar si el usuario está logueado y es admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

// Incluir conexión a la base de datos
require_once '../../config/conexion.php';

// Obtener datos del administrador desde la base de datos
try {
    $stmt = $pdo->prepare("SELECT name, email FROM admins WHERE id = ?");
    $stmt->execute([$_SESSION['admin_id']]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$admin) {
        // Si no se encuentra el admin, cerrar sesión
        session_destroy();
        header("Location: ../login.php");
        exit();
    }
    
    $admin_name = $admin['name'];
    $admin_email = $admin['email'];
} catch(PDOException $e) {
    die("Error al obtener datos del administrador: " . $e->getMessage());
}
?>