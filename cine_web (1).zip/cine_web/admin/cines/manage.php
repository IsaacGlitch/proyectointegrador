<?php
// Verificar autenticación de administrador
require_once 'admin_check.php';

// Consultar todos los cines
$sql = "SELECT * FROM cines ORDER BY creado DESC";
$stmt = $pdo->query($sql);
$cines = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Cines - Sistema de Cine</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/manage.css"> <!-- Se separa el CSS -->
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="header-content">
                <div class="header-info">
                    <h1><i class="fas fa-building"></i> Gestión de Cines</h1>
                    <div class="subtitle">Panel de Administración</div>
                </div>
                <a href="../logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                    Cerrar Sesión
                </a>
            </div>
        </div>

        <!-- Navigation Bar -->
        <nav class="nav-bar">
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="../dashboard.php" class="nav-link">
                        <span><i class="fas fa-home"></i> Inicio</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../peliculas/manage.php" class="nav-link">
                        <span><i class="fas fa-film"></i> Películas</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../cines/manage.php" class="nav-link active">
                        <span><i class="fas fa-building"></i> Cines</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../profile.php" class="nav-link">
                        <span><i class="fas fa-user-cog"></i> Mi Cuenta</span>
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Content -->
        <div class="content">
            <a href="agregar.php" class="add-button">
                <i class="fas fa-plus"></i>
                Agregar Nuevo Cine
            </a>

            <?php if (count($cines) > 0): ?>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th><i class="fas fa-hashtag"></i> ID</th>
                            <th><i class="fas fa-image"></i> Cine</th>
                            <th><i class="fas fa-map-marker-alt"></i> Dirección</th>
                            <th><i class="fas fa-city"></i> Ciudad</th>
                            <th><i class="fas fa-phone"></i> Teléfono</th>
                            <th><i class="fas fa-clock"></i> Horario</th>
                            <th><i class="fas fa-cogs"></i> Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($cines as $cine) {
                            echo '<tr>';
                            echo '<td><span class="id-badge">' . htmlspecialchars($cine['id']) . '</span></td>';
                            echo '<td>';
                            echo '<div class="cinema-info">';
                            
                            // Mostrar imagen o placeholder
                            if (!empty($cine['imagen'])) {
                                echo '<img src="' . htmlspecialchars($cine['imagen']) . '" alt="' . htmlspecialchars($cine['nombre']) . '" class="cinema-thumbnail" onclick="showImageModal(\'' . htmlspecialchars($cine['imagen']) . '\', \'' . htmlspecialchars($cine['nombre']) . '\')" onerror="this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';">';
                                echo '<div class="no-image" style="display: none;"><i class="fas fa-building"></i></div>';
                            } else {
                                echo '<div class="no-image"><i class="fas fa-building"></i></div>';
                            }
                            
                            echo '<span class="cinema-name">' . htmlspecialchars($cine['nombre']) . '</span>';
                            echo '</div>';
                            echo '</td>';
                            echo '<td><span class="address">' . htmlspecialchars($cine['direccion']) . '</span></td>';
                            echo '<td><span class="city-badge">' . htmlspecialchars($cine['ciudad']) . '</span></td>';
                            echo '<td><span class="phone">' . htmlspecialchars($cine['telefono']) . '</span></td>';
                            echo '<td><span class="schedule">' . htmlspecialchars($cine['horario_atencion']) . '</span></td>';
                            echo '<td>';
                            echo '<div class="actions">';
                            echo '<a href="editar.php?id=' . $cine['id'] . '" class="action-btn edit-btn"><i class="fas fa-edit"></i> Editar</a>';
                            echo '<a href="eliminar.php?id=' . $cine['id'] . '" class="action-btn delete-btn" onclick="return confirm(\'¿Estás seguro de eliminar este cine?\')"><i class="fas fa-trash"></i> Eliminar</a>';
                            echo '</div>';
                            echo '</td>';
                            echo '</tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-building"></i>
                <h3>No hay cines registrados</h3>
                <p>Comienza agregando tu primer cine</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal para vista ampliada de imagen -->
    <div id="imageModal" class="image-modal" onclick="closeImageModal()">
        <span class="close-modal" onclick="closeImageModal()">&times;</span>
        <div class="modal-content">
            <img id="modalImage" class="modal-image" src="" alt="">
        </div>
    </div>

    <script src="js/manage.js"></script> <!-- Se separa el JavaScript -->
</body>
</html>