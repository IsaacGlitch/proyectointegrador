<?php
session_start();
// Incluir la conexión a la base de datos
require_once '../config/conexion.php';

$success_message = '';
$error_message = '';

// Si el administrador ya está logueado, redirige al dashboard
if (isset($_SESSION['admin_id'])) {
    header("Location: dashboard.php");
    exit();
}

if ($_POST) {
    $email = trim($_POST['email'] ?? '');  // Obtener y limpiar el email del formulario
    $password = $_POST['password'] ?? '';  // Obtener la contraseña del formulario

    // Verificar que los campos no estén vacíos
    if (empty($email) || empty($password)) {
        $error_message = "Por favor, complete todos los campos.";  // Error si algún campo está vacío
    } else {
        try {
            // Preparar la consulta SQL para obtener los datos del administrador por su email
            $stmt = $pdo->prepare("SELECT id, name, email, password FROM admins WHERE email = :email");
            $stmt->bindParam(':email', $email);  // Vincular el email al parámetro en la consulta
            $stmt->execute();  // Ejecutar la consulta

            // Obtener los datos del administrador desde la base de datos
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);

            // Comparar la contraseña ingresada con la contraseña almacenada en la base de datos
            if ($admin && $password === $admin['password']) {
                // Si la autenticación es exitosa, iniciar sesión
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_name'] = $admin['name'];
                $_SESSION['admin_email'] = $admin['email'];

                header("Location: dashboard.php");
                exit();
            } else {
                $error_message = "Email o contraseña incorrecto.";
            }
        } catch (PDOException $e) {
            // Capturar errores de conexión a la base de datos
            $error_message = "Error de conexión: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - CineAdmin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
<div class="login-container">
    <div class="login-header">
        <h1><i class="fas fa-film"></i> Cinepoint</h1>
        <div class="subtitle">Panel de Administración</div>
    </div>

    <form class="login-form" method="POST">
        <?php if ($error_message): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <?= htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <div class="form-group">
            <label for="email">
                <i class="fas fa-envelope"></i> Correo Electrónico
            </label>
            <input type="email" name="email" id="email" required
                   value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
        </div>

        <div class="form-group">
            <label for="password">
                <i class="fas fa-lock"></i> Contraseña
            </label>
            <input type="password" name="password" id="password" required>
        </div>

        <button type="submit" class="login-btn">
            <i class="fas fa-sign-in-alt"></i> Iniciar Sesión
        </button>

        <div class="security-note">
            <i class="fas fa-shield-alt"></i> Solo administradores autorizados pueden acceder
        </div>
    </form>
</div>

    <script src="js/login.js"></script> <!-- Se separa el JavaScript -->
</body>
</html>