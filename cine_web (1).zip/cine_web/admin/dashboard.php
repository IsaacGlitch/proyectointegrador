<?php
// Verificar autenticación de administrador
require_once 'admin_check.php';

// Obtener las últimas películas agregadas desde la base de datos
try {
    $stmt = $pdo->prepare("
        SELECT id, titulo, genero, duracion, precio, stock, imagen, creado 
        FROM peliculas 
        ORDER BY creado DESC 
        LIMIT 4
    ");
    $stmt->execute();
    $latest_movies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    die("Error al obtener películas: " . $e->getMessage());
}

// Obtener estadísticas adicionales
try {
    // Total de películas
    $stmt = $pdo->prepare("SELECT COUNT(*) as total_movies FROM peliculas");
    $stmt->execute();
    $total_movies = $stmt->fetch(PDO::FETCH_ASSOC)['total_movies'];
    
    // Películas con stock bajo (menos de 10)
    $stmt = $pdo->prepare("SELECT COUNT(*) as low_stock FROM peliculas WHERE stock < 10");
    $stmt->execute();
    $low_stock_movies = $stmt->fetch(PDO::FETCH_ASSOC)['low_stock'];
    
    // Valor total del inventario
    $stmt = $pdo->prepare("SELECT SUM(precio * stock) as total_inventory FROM peliculas");
    $stmt->execute();
    $total_inventory = $stmt->fetch(PDO::FETCH_ASSOC)['total_inventory'] ?? 0;
    
} catch(PDOException $e) {
    $total_movies = 0;
    $low_stock_movies = 0;
    $total_inventory = 0;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Administrador - Sistema de Cine</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/dashboard.css">
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="header-content">
                <div class="admin-info">
                    <h1><i class="fas fa-film"></i> Cinepoint - Admin</h1>
                    <div class="admin-welcome">
                        Bienvenido, <?php echo htmlspecialchars($admin_name); ?>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                    Cerrar Sesión
                </a>
            </div>
        </div>

        <!-- Navigation Bar -->
        <nav class="nav-bar">
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link active">
                        <span><i class="fas fa-home"></i> Inicio</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="peliculas/manage.php" class="nav-link">
                        <span><i class="fas fa-film"></i> Películas</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="cines/manage.php" class="nav-link">
                        <span><i class="fas fa-building"></i> Cines</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="profile.php" class="nav-link">
                        <span><i class="fas fa-user-cog"></i> Mi Cuenta</span>
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Content -->
        <div class="content">
            <!-- Estadísticas Overview -->
            <div class="stats-overview">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-film"></i>
                    </div>
                    <div class="stat-number"><?php echo $total_movies; ?></div>
                    <div class="stat-label">Total Películas</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="stat-number"><?php echo $low_stock_movies; ?></div>
                    <div class="stat-label">Stock Bajo</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div class="stat-number">$<?php echo number_format($total_inventory, 2); ?></div>
                    <div class="stat-label">Valor Inventario</div>
                </div>
            </div>

            <div class="section-header">
                <h2 class="section-title">
                    <i class="fas fa-clock"></i> Últimas Películas Agregadas
                </h2>
                <a href="peliculas/manage.php" class="view-all-btn">
                    <i class="fas fa-arrow-right"></i>
                    Ver Todas
                </a>
            </div>

            <?php if (empty($latest_movies)): ?>
                <div class="empty-state">
                    <i class="fas fa-film"></i>
                    <h3>Aún no hay películas</h3>
                    <p>No se han agregado películas al sistema. Comienza agregando tu primera película.</p>
                    <a href="peliculas/manage.php" class="add-movie-btn">
                        <i class="fas fa-plus"></i>
                        Agregar Primera Película
                    </a>
                </div>
            <?php else: ?>
                <div class="movies-grid">
                    <?php foreach ($latest_movies as $movie): ?>
                    <div class="movie-card">
                        <img src="<?php echo htmlspecialchars($movie['imagen'] ?? 'https://via.placeholder.com/300x400/95a5a6/ffffff?text=Sin+Imagen'); ?>" 
                             alt="<?php echo htmlspecialchars($movie['titulo']); ?>" 
                             class="movie-image"
                             onerror="this.src='https://via.placeholder.com/300x400/95a5a6/ffffff?text=Sin+Imagen'">
                        
                        <div class="movie-info">
                            <h3 class="movie-title"><?php echo htmlspecialchars($movie['titulo']); ?></h3>
                            
                            <div class="movie-details">
                                <div class="genre-badge">
                                    <?php echo htmlspecialchars($movie['genero']); ?>
                                </div>
                                
                                <div class="duration">
                                    <i class="fas fa-clock"></i>
                                    <?php echo htmlspecialchars($movie['duracion']); ?>
                                </div>
                                
                                <div class="stats-row">
                                    <div class="price">
                                        <i class="fas fa-dollar-sign"></i>
                                        <?php echo number_format($movie['precio'], 2); ?>
                                    </div>
                                    
                                    <div class="stock <?php 
                                        if ($movie['stock'] > 20) echo 'high';
                                        elseif ($movie['stock'] > 10) echo 'medium';
                                        else echo 'low';
                                    ?>">
                                        <?php echo $movie['stock']; ?> disponibles
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="js/dashboard.js"></script> <!-- Se separa el JavaScript -->
</body>
</html>