document.getElementById('loginForm').addEventListener('submit', function (e) {
    const btn = this.querySelector('.login-btn');
    const btnText = btn.innerHTML;

    // Mostrar estado de carga
    btn.innerHTML = '<div class="spinner"></div> Iniciando sesión...';
    btn.classList.add('loading');

    // Simular delay para mostrar la animación
    setTimeout(() => {
        // El formulario se enviará normalmente
    }, 100);
});

// Animación de entrada
document.addEventListener('DOMContentLoaded', function () {
    const container = document.querySelector('.login-container');
    container.style.opacity = '0';
    container.style.transform = 'translateY(20px)';

    setTimeout(() => {
        container.style.transition = 'all 0.6s ease';
        container.style.opacity = '1';
        container.style.transform = 'translateY(0)';
    }, 100);
});
