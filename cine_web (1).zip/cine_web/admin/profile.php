<?php
// Verificar autenticación de administrador
require_once 'admin_check.php';

// Variables para mensajes
$success_message = '';
$error_message = '';

// Procesar cambio de contraseña
if ($_POST && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validaciones
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error_message = "Todos los campos son obligatorios.";
    } elseif ($new_password !== $confirm_password) {
        $error_message = "La nueva contraseña y la confirmación no coinciden.";
    } elseif (strlen($new_password) < 5) {
        $error_message = "La nueva contraseña debe tener al menos 5 caracteres.";
    } else {
        try {
            // Verificar contraseña actual
            $stmt = $pdo->prepare("SELECT password FROM admins WHERE id = ?");
            $stmt->execute([$_SESSION['admin_id']]);
            $admin_data = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($admin_data && $current_password === $admin_data['password']) {
                // Actualizar contraseña
                $hashed_password = $new_password;
                $stmt = $pdo->prepare("UPDATE admins SET password = ? WHERE id = ?");
                
                if ($stmt->execute([$hashed_password, $_SESSION['admin_id']])) {
                    $success_message = "Contraseña actualizada exitosamente.";
                } else {
                    $error_message = "Error al actualizar la contraseña.";
                }
            } else {
                $error_message = "La contraseña actual es incorrecta.";
            }
        } catch(PDOException $e) {
            $error_message = "Error al procesar la solicitud: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil - Sistema de Cine</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/profile.css">
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="header-content">
                <div class="header-left">
                    <a href="dashboard.php" class="back-btn">
                        <i class="fas fa-arrow-left"></i>
                        Regresar
                    </a>
                    <div class="page-title">
                        <h1><i class="fas fa-user-cog"></i> Mi Perfil</h1>
                        <div class="page-subtitle">Gestiona tu información personal</div>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                    Cerrar Sesión
                </a>
            </div>
        </div>

        <!-- Content -->
        <div class="content">
            <div class="content-wrapper">
                <!-- Información del Perfil -->
                <div class="profile-section">
                    <h2 class="section-title">
                        <i class="fas fa-id-card"></i>
                        Información Personal
                    </h2>

                    <div class="avatar-section">
                        <div class="avatar">
                            <?php echo strtoupper(substr($admin_name, 0, 1)); ?>
                        </div>
                        <div class="avatar-name"><?php echo htmlspecialchars($admin_name); ?></div>
                        <div class="avatar-role">Administrador del Sistema</div>
                    </div>

                    <div class="profile-info">
                        <div class="info-field">
                            <div class="field-label">Nombre Completo</div>
                            <div class="field-value"><?php echo htmlspecialchars($admin_name); ?></div>
                        </div>

                        <div class="info-field">
                            <div class="field-label">Correo Electrónico</div>
                            <div class="field-value"><?php echo htmlspecialchars($admin_email); ?></div>
                        </div>

                        <div class="created-date">
                            <i class="fas fa-calendar-alt"></i> 
                            Cuenta creada: <?php echo date('d/m/Y', strtotime($admin_created)); ?>
                        </div>
                    </div>
                </div>

                <!-- Cambiar Contraseña -->
                <div class="profile-section">
                    <h2 class="section-title">
                        <i class="fas fa-lock"></i>
                        Cambiar Contraseña
                    </h2>

                    <?php if ($success_message): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i>
                            <?php echo htmlspecialchars($success_message); ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($error_message): ?>
                        <div class="alert alert-error">
                            <i class="fas fa-exclamation-circle"></i>
                            <?php echo htmlspecialchars($error_message); ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" class="password-form">
                        <div class="form-group">
                            <label for="current_password" class="form-label">Contraseña actual</label>
                            <input type="password" id="current_password" name="current_password" 
                                   class="form-input" required>
                        </div>

                        <div class="form-group">
                            <label for="new_password" class="form-label">Nueva contraseña</label>
                            <input type="password" id="new_password" name="new_password" 
                                   class="form-input" minlength="5" required>
                        </div>

                        <div class="form-group">
                            <label for="confirm_password" class="form-label">Confirmar nueva contraseña</label>
                            <input type="password" id="confirm_password" name="confirm_password" 
                                   class="form-input" minlength="5" required>
                        </div>

                        <div class="password-requirements">
                            <div class="requirements-title">Requisitos de la contraseña:</div>
                            <ul class="requirements-list">
                                <li><i class="fas fa-check"></i> Mínimo 5 caracteres</li>
                                <li><i class="fas fa-check"></i> Se recomienda usar mayúsculas y minúsculas</li>
                                <li><i class="fas fa-check"></i> Se recomienda incluir números</li>
                            </ul>
                        </div>

                        <button type="submit" name="change_password" class="btn-primary">
                            <i class="fas fa-save"></i>
                            Cambiar Contraseña
                        </button>
                    </form>
                </div>

                <!-- Mensaje informativo -->
                <div class="info-message">
                    <i class="fas fa-info-circle"></i>
                    <span>Mantén tu información actualizada para una mejor experiencia en el sistema</span>
                </div>
            </div>
        </div>
    </div>

    <script src="js/profile.js"></script> <!-- Se separa el JavaScript -->
</body>
</html>