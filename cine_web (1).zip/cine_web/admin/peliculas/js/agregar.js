// Contador de caracteres
function setupCharCounter(inputId, counterId, maxLength) {
    const input = document.getElementById(inputId);
    const counter = document.getElementById(counterId);
    
    input.addEventListener('input', function() {
        const currentLength = this.value.length;
        counter.textContent = `${currentLength}/${maxLength}`;
        
        if (currentLength > maxLength * 0.9) {
            counter.style.color = '#e74c3c';
        } else if (currentLength > maxLength * 0.7) {
            counter.style.color = '#f39c12';
        } else {
            counter.style.color = '#7f8c8d';
        }
    });
}

// Preview de imagen (póster)
document.getElementById('imagen').addEventListener('input', function() {
    const url = this.value;
    const preview = document.getElementById('imagePreview');
    
    if (url) {
        preview.innerHTML = `<img src="${url}" alt="Preview Póster" onerror="this.parentNode.innerHTML='<p style=color:#e74c3c><i class=fas fa-exclamation-triangle></i> Error al cargar la imagen</p>'">`;
    } else {
        preview.innerHTML = '';
    }
});

// Preview de imagen de carrusel
document.getElementById('carrusel').addEventListener('input', function() {
    const url = this.value;
    const preview = document.getElementById('carruselPreview');
    
    if (url) {
        preview.className = 'image-preview carousel-preview';
        preview.innerHTML = `<img src="${url}" alt="Preview Carrusel" onerror="this.parentNode.innerHTML='<p style=color:#e74c3c><i class=fas fa-exclamation-triangle></i> Error al cargar la imagen del carrusel</p>'">`;
    } else {
        preview.innerHTML = '';
        preview.className = 'image-preview';
    }
});

// Función para convertir URL de YouTube a embed
function convertToEmbedUrl(url) {
    // YouTube - varios formatos posibles
    const youtubeRegex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
    const youtubeMatch = url.match(youtubeRegex);
    
    if (youtubeMatch) {
        return `https://www.youtube.com/embed/${youtubeMatch[1]}`;
    }
    
    // Si ya es una URL de embed, la devolvemos tal como está
    if (url.includes('youtube.com/embed/')) {
        return url;
    }
    
    return null;
}

// Preview del trailer
document.getElementById('trailer').addEventListener('input', function() {
    const url = this.value;
    const preview = document.getElementById('trailerPreview');
    
    if (url) {
        const embedUrl = convertToEmbedUrl(url);
        
        if (embedUrl) {
            preview.innerHTML = `
                <iframe 
                    src="${embedUrl}" 
                    frameborder="0" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowfullscreen>
                </iframe>
            `;
        } else {
            preview.innerHTML = `
                <p style="color:#e74c3c; text-align:center; padding:20px;">
                    <i class="fas fa-exclamation-triangle"></i> 
                    URL de YouTube no válida.
                </p>
            `;
        }
    } else {
        preview.innerHTML = '';
    }
});

// Función para validar URL de imagen
function isValidImageUrl(url) {
    return new Promise((resolve) => {
        const img = new Image();
        img.onload = () => resolve(true);
        img.onerror = () => resolve(false);
        img.src = url;
    });
}

// Inicializar contadores
setupCharCounter('titulo', 'titulo-counter', 100);
setupCharCounter('genero', 'genero-counter', 50);
setupCharCounter('descripcion', 'descripcion-counter', 500);

// Validación del formulario
document.getElementById('movieForm').addEventListener('submit', function(e) {
    const precio = document.getElementById('precio').value;
    const stock = document.getElementById('stock').value;
    const trailerUrl = document.getElementById('trailer').value;
    const carruselUrl = document.getElementById('carrusel').value;
    
    if (precio < 0) {
        e.preventDefault();
        alert('El precio no puede ser negativo');
        return;
    }
    
    if (stock < 0) {
        e.preventDefault();
        alert('El stock no puede ser negativo');
        return;
    }
    
    // Validar y convertir URL del trailer antes de enviar
    if (trailerUrl) {
        const embedUrl = convertToEmbedUrl(trailerUrl);
        if (embedUrl) {
            // Actualizar el campo con la URL de embed
            document.getElementById('trailer').value = embedUrl;
        } else {
            e.preventDefault();
            alert('Por favor, ingresa una URL válida de YouTube');
            return;
        }
    }
    
    // Validación adicional para la imagen del carrusel (opcional)
    if (carruselUrl && !carruselUrl.match(/^https?:\/\/.+\.(jpg|jpeg|png|gif|webp)$/i)) {
        // Validación básica de URL de imagen
        if (!carruselUrl.startsWith('http')) {
            e.preventDefault();
            alert('La URL de la imagen del carrusel debe comenzar con http:// o https://');
            return;
        }
    }
});

// Agregar tooltips informativos
document.addEventListener('DOMContentLoaded', function() {
    // Tooltip para imagen de carrusel
    const carruselInput = document.getElementById('carrusel');
    const carruselLabel = carruselInput.parentNode.querySelector('label');
    
    carruselLabel.setAttribute('title', 'La imagen del carrusel se mostrará en la página principal. Usa una imagen panorámica de buena calidad.');
    
    // Efectos visuales para campos opcionales
    carruselInput.addEventListener('focus', function() {
        this.style.borderColor = '#3498db';
        this.style.boxShadow = '0 0 0 3px rgba(52, 152, 219, 0.1)';
    });
    
    carruselInput.addEventListener('blur', function() {
        if (!this.value) {
            this.style.borderColor = '#95a5a6';
            this.style.boxShadow = 'none';
        }
    });
});