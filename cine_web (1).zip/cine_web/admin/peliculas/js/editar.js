// Contador de caracteres
function setupCharCounter(inputId, counterId, maxLength) {
    const input = document.getElementById(inputId);
    const counter = document.getElementById(counterId);
    
    function updateCounter() {
        const currentLength = input.value.length;
        counter.textContent = `${currentLength}/${maxLength}`;
        
        if (currentLength > maxLength * 0.9) {
            counter.style.color = '#e74c3c';
        } else if (currentLength > maxLength * 0.7) {
            counter.style.color = '#f39c12';
        } else {
            counter.style.color = '#7f8c8d';
        }
    }
    
    updateCounter(); // Inicializar
    input.addEventListener('input', updateCounter);
}

// Preview de imagen
function updateImagePreview() {
    const url = document.getElementById('imagen').value;
    const preview = document.getElementById('imagePreview');
    
    if (url) {
        preview.innerHTML = `<img src="${url}" alt="Preview" onerror="this.parentNode.innerHTML='<p style=color:#e74c3c><i class=fas fa-exclamation-triangle></i> Error al cargar la imagen</p>'">`;
    } else {
        preview.innerHTML = '';
    }
}

// Preview de imagen del carrusel
function updateCarruselPreview() {
    const url = document.getElementById('carrusel').value;
    const preview = document.getElementById('carruselPreview');
    
    if (url) {
        preview.innerHTML = `
            <div style="position: relative; display: inline-block;">
                <img src="${url}" alt="Preview Carrusel" 
                     style="max-width: 400px; max-height: 200px; border-radius: 12px; box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);" 
                     onerror="this.parentNode.parentNode.innerHTML='<p style=color:#e74c3c><i class=fas fa-exclamation-triangle></i> Error al cargar la imagen del carrusel</p>'">
                <div style="position: absolute; top: 10px; right: 10px; background: rgba(0,0,0,0.7); color: white; padding: 5px 10px; border-radius: 15px; font-size: 0.8rem;">
                    <i class="fas fa-images"></i> Carrusel
                </div>
            </div>
        `;
    } else {
        preview.innerHTML = '';
    }
}

// Función para convertir URL de YouTube a embed
function convertToEmbedUrl(url) {
    // YouTube - varios formatos posibles
    const youtubeRegex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
    const youtubeMatch = url.match(youtubeRegex);
    
    if (youtubeMatch) {
        return `https://www.youtube.com/embed/${youtubeMatch[1]}`;
    }
    
    // Si ya es una URL de embed, la devolvemos tal como está
    if (url.includes('youtube.com/embed/')) {
        return url;
    }
    
    return null;
}

// Preview del trailer
function updateTrailerPreview() {
    const url = document.getElementById('trailer').value;
    const preview = document.getElementById('trailerPreview');
    
    if (url) {
        const embedUrl = convertToEmbedUrl(url);
        
        if (embedUrl) {
            preview.innerHTML = `
                <iframe 
                    src="${embedUrl}" 
                    frameborder="0" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowfullscreen>
                </iframe>
            `;
        } else {
            preview.innerHTML = `
                <p style="color:#e74c3c; text-align:center; padding:20px;">
                    <i class="fas fa-exclamation-triangle"></i> 
                    URL de YouTube no válida.
                </p>
            `;
        }
    } else {
        preview.innerHTML = '';
    }
}

// Event listeners para las previews
document.getElementById('imagen').addEventListener('input', updateImagePreview);
document.getElementById('carrusel').addEventListener('input', updateCarruselPreview);
document.getElementById('trailer').addEventListener('input', updateTrailerPreview);

// Inicializar contadores
setupCharCounter('titulo', 'titulo-counter', 100);
setupCharCounter('genero', 'genero-counter', 50);
setupCharCounter('descripcion', 'descripcion-counter', 500);

// Validación del formulario
document.getElementById('editForm').addEventListener('submit', function(e) {
    const precio = document.getElementById('precio').value;
    const stock = document.getElementById('stock').value;
    const trailerUrl = document.getElementById('trailer').value;
    
    if (precio < 0) {
        e.preventDefault();
        alert('El precio no puede ser negativo');
        return;
    }
    
    if (stock < 0) {
        e.preventDefault();
        alert('El stock no puede ser negativo');
        return;
    }
    
    // Validar y convertir URL del trailer antes de enviar
    if (trailerUrl) {
        const embedUrl = convertToEmbedUrl(trailerUrl);
        if (embedUrl) {
            // Actualizar el campo con la URL de embed
            document.getElementById('trailer').value = embedUrl;
        } else {
            e.preventDefault();
            alert('Por favor, ingresa una URL válida de YouTube');
            return;
        }
    }
});

// Mostrar previews iniciales
updateImagePreview();
updateCarruselPreview();
updateTrailerPreview();