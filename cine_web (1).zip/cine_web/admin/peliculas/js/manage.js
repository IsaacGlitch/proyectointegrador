        // Función para abrir el modal del trailer
        function openTrailer(trailerUrl, movieTitle) {
            const modal = document.getElementById('trailerModal');
            const iframe = document.getElementById('trailerFrame');
            const modalTitle = document.getElementById('modalTitle');
            
            // Establecer el título de la película
            modalTitle.textContent = `Trailer - ${movieTitle}`;
            
            // Establecer la URL del trailer
            iframe.src = trailerUrl;
            
            // Mostrar el modal
            modal.classList.add('show');
            
            // Prevenir scroll del body
            document.body.style.overflow = 'hidden';
        }

        // Función para cerrar el modal del trailer
        function closeTrailer() {
            const modal = document.getElementById('trailerModal');
            const iframe = document.getElementById('trailerFrame');
            
            // Ocultar el modal
            modal.classList.remove('show');
            
            // Detener el video
            iframe.src = '';
            
            // Restaurar scroll del body
            document.body.style.overflow = 'auto';
        }

        // Cerrar modal al hacer click fuera de él
        document.getElementById('trailerModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeTrailer();
            }
        });

        // Cerrar modal con la tecla ESC
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeTrailer();
            }
        });

        // Animación de entrada para las filas de la tabla
        document.addEventListener('DOMContentLoaded', function() {
            const rows = document.querySelectorAll('tbody tr');
            rows.forEach((row, index) => {
                row.style.opacity = '0';
                row.style.transform = 'translateY(20px)';
                
                setTimeout(() => {
                    row.style.transition = 'all 0.6s ease';
                    row.style.opacity = '1';
                    row.style.transform = 'translateY(0)';
                }, index * 50);
            });
        });