<?php
// Verificar autenticación de administrador
require_once 'admin_check.php';

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Recoger los datos del formulario
        $titulo = $_POST['titulo'];
        $descripcion = $_POST['descripcion'];
        $imagen = $_POST['imagen'];
        $genero = $_POST['genero'];
        $duracion = $_POST['duracion'];
        $precio = $_POST['precio'];
        $stock = $_POST['stock'];
        $trailer = $_POST['trailer'];
        $carrusel = !empty($_POST['carrusel']) ? $_POST['carrusel'] : null; // Campo opcional

        // Insertar los datos en la base de datos
        $sql = "INSERT INTO peliculas (titulo, descripcion, imagen, genero, duracion, precio, stock, trailer, carrusel)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$titulo, $descripcion, $imagen, $genero, $duracion, $precio, $stock, $trailer, $carrusel]);

        $success_message = "¡Película agregada exitosamente!";
    } catch (Exception $e) {
        $error_message = "Error al agregar la película: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Película - Administración</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/agregar.css"> <!-- Se separa el CSS -->
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-plus-circle"></i> Agregar Película</h1>
            <p class="subtitle">Añade una nueva película al catálogo</p>
        </div>

        <div class="content">
            <a href="manage.php" class="back-button">
                <i class="fas fa-arrow-left"></i>
                Volver a la lista
            </a>

            <?php if ($success_message): ?>
                <div class="alert success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>

            <?php if ($error_message): ?>
                <div class="alert error">
                    <i class="fas fa-exclamation-triangle"></i>
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <div class="form-tips">
                <h3><i class="fas fa-lightbulb"></i> Consejos para agregar películas:</h3>
                <ul>
                    <li>Usa URLs de imágenes de alta calidad (preferiblemente 300x450px para póster)</li>
                    <li>Para imagen de carrusel usa resolución panorámica (1920x800px recomendado)</li>
                    <li>La duración debe incluir "h" y "min" (ej: "1h 40min")</li>
                    <li>Asegúrate de que el precio sea un número válido</li>
                    <li>El stock debe ser un número entero positivo</li>
                    <li><strong>Para YouTube:</strong> Usa el formato https://www.youtube.com/watch?v=VIDEO_ID</li>
                </ul>
            </div>

            <div class="form-container">
                <form action="agregar.php" method="POST" id="movieForm">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="titulo">
                                <i class="fas fa-film"></i>
                                Título <span class="required">*</span>
                            </label>
                            <input type="text" name="titulo" id="titulo" required maxlength="100">
                            <div class="char-counter" id="titulo-counter">0/100</div>
                        </div>

                        <div class="form-group">
                            <label for="genero">
                                <i class="fas fa-tags"></i>
                                Género <span class="required">*</span>
                            </label>
                            <input type="text" name="genero" id="genero" required maxlength="50" placeholder="Ej: Acción, Drama, Comedia">
                            <div class="char-counter" id="genero-counter">0/50</div>
                        </div>

                        <div class="form-group">
                            <label for="duracion">
                                <i class="fas fa-clock"></i>
                                Duración <span class="required">*</span>
                            </label>
                            <input type="text" name="duracion" id="duracion" required placeholder="Ej: 1h 40min">
                        </div>

                        <div class="form-group">
                            <label for="precio">
                                <i class="fas fa-dollar-sign"></i>
                                Precio <span class="required">*</span>
                            </label>
                            <input type="number" name="precio" id="precio" required step="0.01" min="0" placeholder="0.00">
                        </div>

                        <div class="form-group">
                            <label for="stock">
                                <i class="fas fa-boxes"></i>
                                Stock <span class="required">*</span>
                            </label>
                            <input type="number" name="stock" id="stock" required min="0" placeholder="0">
                        </div>

                        <div class="form-group full-width">
                            <label for="imagen">
                                <i class="fas fa-image"></i>
                                URL de la Imagen (Póster) <span class="required">*</span>
                            </label>
                            <input type="url" name="imagen" id="imagen" required placeholder="https://ejemplo.com/poster.jpg">
                            <div class="image-preview" id="imagePreview"></div>
                        </div>

                        <div class="form-group full-width">
                            <label for="carrusel">
                                <i class="fas fa-images"></i>
                                URL de Imagen para Carrusel <span class="optional">(Opcional)</span>
                            </label>
                            <input type="url" name="carrusel" id="carrusel" placeholder="https://ejemplo.com/carrusel.jpg">
                            <div class="image-preview" id="carruselPreview"></div>
                            <small class="help-text">
                                <i class="fas fa-info-circle"></i>
                                Imagen panorámica para mostrar en el carrusel principal (1920x800px recomendado)
                            </small>
                        </div>

                        <div class="form-group full-width">
                            <label for="trailer">
                                <i class="fas fa-play-circle"></i>
                                URL del Trailer (YouTube) <span class="required">*</span>
                            </label>
                            <input type="url" name="trailer" id="trailer" required placeholder="https://www.youtube.com/watch?v=VIDEO_ID">
                            <div class="trailer-preview" id="trailerPreview"></div>
                            <small class="help-text">
                                <i class="fas fa-info-circle"></i>
                                Pega la URL del video de YouTube. Se convertirá automáticamente al formato embed.
                            </small>
                        </div>

                        <div class="form-group full-width">
                            <label for="descripcion">
                                <i class="fas fa-align-left"></i>
                                Descripción <span class="required">*</span>
                            </label>
                            <textarea name="descripcion" id="descripcion" required maxlength="500" placeholder="Describe la trama de la película..."></textarea>
                            <div class="char-counter" id="descripcion-counter">0/500</div>
                        </div>
                    </div>

                    <button type="submit" class="submit-button">
                        <i class="fas fa-save"></i>
                        Agregar Película
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script src="js/agregar.js"></script> <!-- Se separa el JavaScript -->
</body>
</html>