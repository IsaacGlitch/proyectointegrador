<?php
// Verificar autenticación de administrador
require_once 'admin_check.php';

// Consultar todas las películas
$sql = "SELECT * FROM peliculas ORDER BY creado DESC";
$stmt = $pdo->query($sql);
$peliculas = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Películas - Sistema de Cine</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/manage.css"> <!-- Se separa el CSS -->
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="header-content">
                <div class="header-info">
                    <h1><i class="fas fa-film"></i> Gestión de Películas</h1>
                    <div class="subtitle">Panel de Administración</div>
                </div>
                <a href="../logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                    Cerrar Sesión
                </a>
            </div>
        </div>

        <!-- Navigation Bar -->
        <nav class="nav-bar">
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="../dashboard.php" class="nav-link">
                        <span><i class="fas fa-home"></i> Inicio</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../peliculas/manage.php" class="nav-link active">
                        <span><i class="fas fa-film"></i> Películas</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../cines/manage.php" class="nav-link">
                        <span><i class="fas fa-building"></i> Cines</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../profile.php" class="nav-link">
                        <span><i class="fas fa-user-cog"></i> Mi Cuenta</span>
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Content -->
        <div class="content">
            <a href="agregar.php" class="add-button">
                <i class="fas fa-plus"></i>
                Agregar Nueva Película
            </a>

            <?php if (count($peliculas) > 0): ?>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th><i class="fas fa-hashtag"></i> ID</th>
                            <th><i class="fas fa-image"></i> Imagen</th>
                            <th><i class="fas fa-film"></i> Título</th>
                            <th><i class="fas fa-tags"></i> Género</th>
                            <th><i class="fas fa-clock"></i> Duración</th>
                            <th><i class="fas fa-dollar-sign"></i> Precio</th>
                            <th><i class="fas fa-boxes"></i> Stock</th>
                            <th><i class="fas fa-play-circle"></i> Trailer</th>
                            <th><i class="fas fa-cogs"></i> Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($peliculas as $pelicula) {
                            // Determinar clase del stock
                            $stockClass = 'high';
                            if ($pelicula['stock'] <= 5) {
                                $stockClass = 'low';
                            } elseif ($pelicula['stock'] <= 15) {
                                $stockClass = 'medium';
                            }

                            echo '<tr>';
                            echo '<td><span class="id-badge">' . htmlspecialchars($pelicula['id']) . '</span></td>';
                            
                            // Columna de imagen
                            echo '<td>';
                            if (!empty($pelicula['imagen'])) {
                                echo '<img src="' . htmlspecialchars($pelicula['imagen']) . '" alt="' . htmlspecialchars($pelicula['titulo']) . '" class="movie-image" onerror="this.parentNode.innerHTML=\'<div class=&quot;no-image&quot;><i class=&quot;fas fa-image&quot;></i></div>\'">';
                            } else {
                                echo '<div class="no-image"><i class="fas fa-image"></i></div>';
                            }
                            echo '</td>';
                            
                            echo '<td><span class="movie-title">' . htmlspecialchars($pelicula['titulo']) . '</span></td>';
                            echo '<td><span class="genre-badge">' . htmlspecialchars($pelicula['genero']) . '</span></td>';
                            echo '<td><span class="duration">' . htmlspecialchars($pelicula['duracion']) . '</span></td>';
                            echo '<td><span class="price">$' . number_format($pelicula['precio'], 2) . '</span></td>';
                            echo '<td><span class="stock ' . $stockClass . '">' . htmlspecialchars($pelicula['stock']) . '</span></td>';
                            
                            // Columna de trailer
                            echo '<td>';
                            if (!empty($pelicula['trailer'])) {
                                echo '<button class="trailer-btn" onclick="openTrailer(\'' . htmlspecialchars($pelicula['trailer'], ENT_QUOTES) . '\', \'' . htmlspecialchars($pelicula['titulo'], ENT_QUOTES) . '\')">';
                                echo '<i class="fas fa-play"></i> Ver';
                                echo '</button>';
                            } else {
                                echo '<button class="trailer-btn" disabled>';
                                echo '<i class="fas fa-play-slash"></i> N/A';
                                echo '</button>';
                            }
                            echo '</td>';
                            
                            echo '<td>';
                            echo '<div class="actions">';
                            echo '<a href="editar.php?id=' . $pelicula['id'] . '" class="action-btn edit-btn"><i class="fas fa-edit"></i> Editar</a>';
                            echo '<a href="eliminar.php?id=' . $pelicula['id'] . '" class="action-btn delete-btn" onclick="return confirm(\'¿Estás seguro de eliminar esta película?\')"><i class="fas fa-trash"></i> Eliminar</a>';
                            echo '</div>';
                            echo '</td>';
                            echo '</tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-film"></i>
                <h3>No hay películas registradas</h3>
                <p>Comienza agregando tu primera película</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal para el trailer -->
    <div id="trailerModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">
                    <i class="fas fa-play-circle"></i>
                    <span id="modalTitle">Trailer</span>
                </h2>
                <button class="close-btn" onclick="closeTrailer()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="trailer-container">
                <iframe id="trailerFrame" src="" allowfullscreen></iframe>
            </div>
        </div>
    </div>

    <script src="js/manage.js"></script> <!-- Se separa el JavaScript -->
</body>
</html>