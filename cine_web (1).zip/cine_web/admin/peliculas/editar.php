<?php
// Verificar autenticación de administrador
require_once 'admin_check.php';

$success_message = '';
$error_message = '';

// Obtener el ID de la película desde la URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: manage.php');
    exit;
}

$id_pelicula = $_GET['id'];

// Consultar la película específica para editar
$sql = "SELECT * FROM peliculas WHERE id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id_pelicula]);
$pelicula = $stmt->fetch();

// Verificar si la película existe
if (!$pelicula) {
    $error_message = "Película no encontrada.";
} else {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        try {
            // Recoger los datos del formulario
            $titulo = $_POST['titulo'];
            $descripcion = $_POST['descripcion'];
            $imagen = $_POST['imagen'];
            $genero = $_POST['genero'];
            $duracion = $_POST['duracion'];
            $precio = $_POST['precio'];
            $stock = $_POST['stock'];
            $trailer = $_POST['trailer'];
            $carrusel = !empty($_POST['carrusel']) ? $_POST['carrusel'] : null; // Campo opcional

            // Actualizar los datos de la película en la base de datos
            $sql = "UPDATE peliculas SET titulo = ?, descripcion = ?, imagen = ?, genero = ?, duracion = ?, precio = ?, stock = ?, trailer = ?, carrusel = ? WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$titulo, $descripcion, $imagen, $genero, $duracion, $precio, $stock, $trailer, $carrusel, $id_pelicula]);

            $success_message = "¡Película actualizada exitosamente!";
            
            // Refrescar los datos de la película
            $sql = "SELECT * FROM peliculas WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$id_pelicula]);
            $pelicula = $stmt->fetch();
        } catch (Exception $e) {
            $error_message = "Error al actualizar la película: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Película - Administración</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/editar.css"> <!-- Se separa el CSS -->
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-edit"></i> Editar Película</h1>
            <p class="subtitle">Modifica los datos de la película</p>
            <?php if ($pelicula): ?>
                <div class="movie-id">ID: <?php echo htmlspecialchars($pelicula['id']); ?></div>
            <?php endif; ?>
        </div>

        <div class="content">
            <div class="navigation">
                <a href="manage.php" class="nav-button back-button">
                    <i class="fas fa-arrow-left"></i>
                    Volver a la lista
                </a>
            </div>

            <?php if ($success_message): ?>
                <div class="alert success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>

            <?php if ($error_message): ?>
                <div class="alert error">
                    <i class="fas fa-exclamation-triangle"></i>
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <?php if ($pelicula): ?>
                <div class="current-info">
                    <h3><i class="fas fa-info-circle"></i> Información actual</h3>
                    <div class="current-preview">
                        <div>
                            <?php if (!empty($pelicula['imagen'])): ?>
                                <img src="<?php echo htmlspecialchars($pelicula['imagen']); ?>" 
                                     alt="<?php echo htmlspecialchars($pelicula['titulo']); ?>" 
                                     class="current-image"
                                     onerror="this.parentNode.innerHTML='<div class=\'no-image-current\'><i class=\'fas fa-image\'></i></div>'">
                            <?php else: ?>
                                <div class="no-image-current"><i class="fas fa-image"></i></div>
                            <?php endif; ?>
                        </div>
                        <div class="current-details">
                            <div class="detail-item">
                                <div class="detail-label">Título</div>
                                <div class="detail-value"><?php echo htmlspecialchars($pelicula['titulo']); ?></div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Género</div>
                                <div class="detail-value"><?php echo htmlspecialchars($pelicula['genero']); ?></div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Duración</div>
                                <div class="detail-value"><?php echo htmlspecialchars($pelicula['duracion']); ?></div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Precio</div>
                                <div class="detail-value">$<?php echo number_format($pelicula['precio'], 2); ?></div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Stock</div>
                                <div class="detail-value"><?php echo htmlspecialchars($pelicula['stock']); ?> unidades</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Trailer</div>
                                <div class="detail-value">
                                    <?php if (!empty($pelicula['trailer'])): ?>
                                        <a href="<?php echo htmlspecialchars($pelicula['trailer']); ?>" target="_blank">
                                            <i class="fas fa-play-circle"></i> Ver trailer
                                        </a>
                                    <?php else: ?>
                                        <span style="color: #95a5a6;">Sin trailer</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Carrusel</div>
                                <div class="detail-value">
                                    <?php if (!empty($pelicula['carrusel'])): ?>
                                        <span style="color: #27ae60;">
                                            <i class="fas fa-check-circle"></i> Imagen configurada
                                        </span>
                                    <?php else: ?>
                                        <span style="color: #95a5a6;">Sin imagen de carrusel</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="detail-item" style="grid-column: 1 / -1;">
                                <div class="detail-label">Descripción</div>
                                <div class="detail-value"><?php echo htmlspecialchars(substr($pelicula['descripcion'], 0, 100)) . (strlen($pelicula['descripcion']) > 100 ? '...' : ''); ?></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-container">
                    <div class="form-header">
                        <h2><i class="fas fa-pencil-alt"></i> Modificar datos</h2>
                        <p>Actualiza los campos que desees cambiar</p>
                    </div>

                    <form action="editar.php?id=<?php echo $pelicula['id']; ?>" method="POST" id="editForm">
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="titulo">
                                    <i class="fas fa-film"></i>
                                    Título <span class="required">*</span>
                                </label>
                                <input type="text" name="titulo" id="titulo" 
                                       value="<?php echo htmlspecialchars($pelicula['titulo']); ?>" 
                                       required maxlength="100">
                                <div class="char-counter" id="titulo-counter"></div>
                            </div>

                            <div class="form-group">
                                <label for="genero">
                                    <i class="fas fa-tags"></i>
                                    Género <span class="required">*</span>
                                </label>
                                <input type="text" name="genero" id="genero" 
                                       value="<?php echo htmlspecialchars($pelicula['genero']); ?>" 
                                       required maxlength="50">
                                <div class="char-counter" id="genero-counter"></div>
                            </div>

                            <div class="form-group">
                                <label for="duracion">
                                    <i class="fas fa-clock"></i>
                                    Duración <span class="required">*</span>
                                </label>
                                <input type="text" name="duracion" id="duracion" 
                                       value="<?php echo htmlspecialchars($pelicula['duracion']); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="precio">
                                    <i class="fas fa-dollar-sign"></i>
                                    Precio <span class="required">*</span>
                                </label>
                                <input type="number" name="precio" id="precio" 
                                       value="<?php echo htmlspecialchars($pelicula['precio']); ?>" 
                                       required step="0.01" min="0">
                            </div>

                            <div class="form-group">
                                <label for="stock">
                                    <i class="fas fa-boxes"></i>
                                    Stock <span class="required">*</span>
                                </label>
                                <input type="number" name="stock" id="stock" 
                                       value="<?php echo htmlspecialchars($pelicula['stock']); ?>" 
                                       required min="0">
                            </div>

                            <div class="form-group full-width">
                                <label for="imagen">
                                    <i class="fas fa-image"></i>
                                    URL de la Imagen <span class="required">*</span>
                                </label>
                                <input type="url" name="imagen" id="imagen" 
                                       value="<?php echo htmlspecialchars($pelicula['imagen']); ?>" required>
                                <div class="image-preview" id="imagePreview"></div>
                            </div>

                            <div class="form-group full-width">
                                <label for="carrusel">
                                    <i class="fas fa-images"></i>
                                    URL de Imagen para Carrusel <span class="optional">(Opcional)</span>
                                </label>
                                <input type="url" name="carrusel" id="carrusel" 
                                       value="<?php echo htmlspecialchars($pelicula['carrusel'] ?? ''); ?>" 
                                       placeholder="https://ejemplo.com/imagen-carrusel.jpg">
                                <div class="image-preview" id="carruselPreview"></div>
                                <small class="help-text">
                                    <i class="fas fa-info-circle"></i>
                                    Esta imagen se usará en el carrusel principal. Se recomienda una imagen horizontal de alta calidad (1920x1080px o similar).
                                </small>
                            </div>

                            <div class="form-group full-width">
                                <label for="trailer">
                                    <i class="fas fa-play-circle"></i>
                                    URL del Trailer (YouTube) <span class="required">*</span>
                                </label>
                                <input type="url" name="trailer" id="trailer" 
                                       value="<?php echo htmlspecialchars($pelicula['trailer'] ?? ''); ?>" 
                                       required placeholder="https://www.youtube.com/watch?v=VIDEO_ID">
                                <div class="trailer-preview" id="trailerPreview"></div>
                                <small class="help-text">
                                    <i class="fas fa-info-circle"></i>
                                    Pega la URL del video de YouTube. Se convertirá automáticamente al formato embed.
                                </small>
                            </div>

                            <div class="form-group full-width">
                                <label for="descripcion">
                                    <i class="fas fa-align-left"></i>
                                    Descripción <span class="required">*</span>
                                </label>
                                <textarea name="descripcion" id="descripcion" required maxlength="500"><?php echo htmlspecialchars($pelicula['descripcion']); ?></textarea>
                                <div class="char-counter" id="descripcion-counter"></div>
                            </div>
                        </div>

                        <button type="submit" class="submit-button">
                            <i class="fas fa-save"></i>
                            Actualizar Película
                        </button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="js/editar.js"></script> <!-- Se separa el JavaScript -->
</body>
</html>